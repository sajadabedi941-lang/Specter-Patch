SPECTER SS2 America Patriot PAC-3 — STAGE 1 restore (not a crash fix)

This pack restores live CommandSet.ini and CommandButton.ini (no Patriot slot 10,
no construct button). It cannot delete files. After unzip into SPECTER FINAL:

  1. Delete Data/INI/Object/Specter/United States Of America/AirDefense/AmericaVehiclePatriotPAC3.ini
     if that file exists.
  2. Confirm AmericaCommandCenterCommandSet has no Command_ConstructAmericaVehiclePatriotPAC3.
  3. Start a match as America and wait through the countdown.

This is an isolation test, not a Patriot fix. Original SS2 in this environment
was not modified.
