Specter FINAL FILE AUDIT PASS
=============================

PATCH_FINAL_AUDIT_REPORT.txt: PASS
  Object duplicate    = 0
  ModuleTag duplicate = 0
  Missing reference   = 0
  Wrong path          = 0
  Empty required INI  = 0

Easiest install (recommended):
  1. Extract this ZIP anywhere (or into your game folder)
  2. Double-click RUN_PATCH_FIX.bat
  3. Game folder is detected automatically
     - If this folder already has Data\ + generals.exe, it is used
     - Else parent folders are checked
     - Else a folder picker opens (no typing; spaces OK)
  4. Wait for: Game detected -> Backup created -> Patch installing -> Installation completed

Manual:
  Install_Final_Audit_Pass.bat

Files:
  RUN_PATCH_FIX.bat          auto launcher
  Detect_GameRoot.ps1        GameRoot detection helper
  Install_Final_Audit_Pass.bat
  Install_Runtime_Fix.ps1
  Data\                      corrected faction-path INIs
  FlatIniBlacklist.txt
  PATCH_FINAL_AUDIT_REPORT.txt
