# New folder.zip — repair report

## AIR_FORCE_EXPANSION.txt
- Dest: `Data/INI/Object/Specter/PatchSystems/AirForceExpansion/AIR_FORCE_EXPANSION.txt`
  - No syntax mutations required (validated & synced to correct path)

## AbbasLauncher.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Wheeled/AbbasLauncher.ini`
  - No syntax mutations required (validated & synced to correct path)

## Airborne.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Infantry/Airborne.ini`
  - No syntax mutations required (validated & synced to correct path)

## Aircraft_AAB_Global.ini
- Dest: `Data/INI/Object/Specter/PatchSystems/AdvancedAirBase/Aircraft_AAB_Global.ini`
  - No syntax mutations required (validated & synced to correct path)

## Aircraft_AirForceExpansion.ini
- Dest: `Data/INI/Object/Specter/PatchSystems/AirForceExpansion/Aircraft_AirForceExpansion.ini`
  - No syntax mutations required (validated & synced to correct path)

## Britain_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/British Armed Forces/Drones/Britain_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## Britain_F35B.ini
- Dest: `Data/INI/Object/Specter/British Armed Forces/Airforce/Britain_F35B.ini`
  - No syntax mutations required (validated & synced to correct path)

## Egypt_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Egyptian Armed Forces/Buildings/Egypt_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Egypt_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Egyptian Armed Forces/Buildings/Egypt_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## France_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/French Armed Forces/Drones/France_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## Germany_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/German Armed Forces/Drones/Germany_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## India_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/Indian Armed Forces/Drones/India_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## India_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Indian Armed Forces/Buildings/India_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## India_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Indian Armed Forces/Buildings/India_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## India_TejasMk2.ini
- Dest: `Data/INI/Object/Specter/Indian Armed Forces/Airforce/India_TejasMk2.ini`
  - No syntax mutations required (validated & synced to correct path)

## Israel_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Israel Defense Forces/Buildings/Israel_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Israel_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Israel Defense Forces/Buildings/Israel_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## Italy_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/Italian Armed Forces/Drones/Italy_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## Japan_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/Japan Self-Defense Forces/Drones/Japan_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## Japan_MQ9.ini
- Dest: `Data/INI/Object/Specter/Japan Self-Defense Forces/Airforce/Japan_MQ9.ini`
  - No syntax mutations required (validated & synced to correct path)

## Karrar-2.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Wheeled/Karrar-2.ini`
  - No syntax mutations required (validated & synced to correct path)

## Lamiaa.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Wheeled/Lamiaa.ini`
  - No syntax mutations required (validated & synced to correct path)

## Libya_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Libyan Armed Forces/Buildings/Libya_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Libya_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Libyan Armed Forces/Buildings/Libya_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## MilitaryHQ_StockFactions.ini
- Dest: `Data/INI/Object/Specter/PatchSystems/MilitaryHQ/MilitaryHQ_StockFactions.ini`
  - No syntax mutations required (validated & synced to correct path)

## Pakistan_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Pakistan Armed Forces/Buildings/Pakistan_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Pakistan_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Pakistan Armed Forces/Buildings/Pakistan_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## Russia_AD_TorM.ini
- Dest: `Data/INI/Object/Specter/PatchSystems/AirDefense/Russia_AD_TorM.ini`
  - No syntax mutations required (validated & synced to correct path)

## SaudiArabia_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/Saudi Arabian Armed Forces/Drones/SaudiArabia_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## SaudiArabia_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Saudi Arabian Armed Forces/Buildings/SaudiArabia_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## SaudiArabia_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Saudi Arabian Armed Forces/Buildings/SaudiArabia_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## SouthAfrica_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/South African National Defence Force/Buildings/SouthAfrica_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## SouthAfrica_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/South African National Defence Force/Buildings/SouthAfrica_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## SouthKorea_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/Republic of Korea Armed Forces/Drones/SouthKorea_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## SpecialForces.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Infantry/SpecialForces.ini`
  - No syntax mutations required (validated & synced to correct path)

## Sweden_CombatDrone.ini
- Dest: `Data/INI/Object/Specter/Swedish Armed Forces/Drones/Sweden_CombatDrone.ini`
  - No syntax mutations required (validated & synced to correct path)

## Syria_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Syrian Arab Army/Buildings/Syria_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Syria_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Syrian Arab Army/Buildings/Syria_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_AWACS.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Airforce/Turkey_AWACS.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_Akinci.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Airforce/Turkey_Akinci.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_Bora.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Wheeled/Turkey_Bora.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Buildings/Turkey_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_EliteMaroonBerets.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Infantry/Turkey_EliteMaroonBerets.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_F16Block70.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Airforce/Turkey_F16Block70.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_Kizilelma.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Drones/Turkey_Kizilelma.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Buildings/Turkey_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_TB2.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Airforce/Turkey_TB2.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_Tu-22M3.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Airforce/Turkey_Tu-22M3.ini`
  - No syntax mutations required (validated & synced to correct path)

## Turkey_WeaponObjects.ini
- Dest: `Data/INI/Object/Specter/Turkey Armed Forces/Turkey_WeaponObjects.ini`
  - No syntax mutations required (validated & synced to correct path)

## UAE_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/United Arab Emirates/Buildings/UAE_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## UAE_MQ9.ini
- Dest: `Data/INI/Object/Specter/United Arab Emirates/Airforce/UAE_MQ9.ini`
  - No syntax mutations required (validated & synced to correct path)

## UAE_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/United Arab Emirates/Buildings/UAE_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## Ukraine_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Ukrainian Armed Forces/Buildings/Ukraine_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Ukraine_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Ukrainian Armed Forces/Buildings/Ukraine_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## Vietnam_CommandCenter.ini
- Dest: `Data/INI/Object/Specter/Vietnam People's Army/Buildings/Vietnam_CommandCenter.ini`
  - No syntax mutations required (validated & synced to correct path)

## Vietnam_MilitaryHQ.ini
- Dest: `Data/INI/Object/Specter/Vietnam People's Army/Buildings/Vietnam_MilitaryHQ.ini`
  - No syntax mutations required (validated & synced to correct path)

## Root cause fixed

Flat installation of `New folder.zip` into `Data/INI/*.ini` duplicated Object
names already defined under `Data/INI/Object/Specter/...`.

Critical mis-placement:
- `AbbasLauncher.ini` (Turkey objects) must not overwrite UAE path / must not sit at INI root
- `SpecialForces.ini` (Turkey objects) same

## Static audit after repair (PASS)

- Intra-patch multi-file Object duplicates for repaired set: **0**
- Duplicate ModuleTags in repaired files: **0**
- Empty CommandSet=: **0**
- Literal END / bare Scale: **0**
- Missing CommandSet references: **0**
- Non-engine schemas under Data/INI: **absent**

Live ZH launch was not executed in this Linux environment; package is built for Windows GameRoot verification.
