Extract this ZIP into the SPECTER / Zero Hour game folder (the folder that contains generals.exe).
It adds a loose overlay at:
  Data\INI\Object\Specter\United States Of America\AirDefense\US_PAC3.ini
Loose Data wins over the packed BIG. Do not replace CommandSet, CommandButton, Weapon.ini, or BIGs.
Test: build USAPAC3, pick Multi Target / Anti Air / Anti Missile, then check Deploy.
